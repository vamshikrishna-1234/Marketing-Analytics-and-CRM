import pandas as pd


def write_to_excel(dict, path):
    writer = pd.ExcelWriter(path=path,
                            engine='xlsxwriter')
    workbook = writer.book
    n_rows = None
    worksheet=workbook.add_worksheet('stats')
    writer.sheets['stats'] = worksheet
    for dimension, table in dict.items():
        # worksheet=workbook.add_worksheet(dimension)
        # writer.sheets[dimension] = worksheet

        if n_rows is None:
            start_row=2
        else:
            start_row=n_rows+2

        table.to_excel(writer,sheet_name='stats',startrow=start_row, startcol=1)
        n_rows=start_row+table.shape[0]
    writer.close()
    return True
