import pandas_gbq
import pydata_google_auth


SCOPES = [
    'https://www.googleapis.com/auth/cloud-platform',
    'https://www.googleapis.com/auth/drive',
]


class dbConnector():
    def __init__(self, project_id):
        self.project_id = project_id
        self.credentials = pydata_google_auth.get_user_credentials(
            SCOPES,
            # Set auth_local_webserver to True to have a slightly more convienient
            # authorization flow. Note, this doesn't work if you're running from a
            # notebook on a remote sever, such as over SSH or with Google Colab.
            auth_local_webserver=True,
        )
    #pandas_gbq.context.credentials = self.credentials


    def upload_to_bq(self, dat, destination_table, if_exists='fail'):
        print(f'Uploading to {destination_table} in project {self.project_id}')
        pandas_gbq.to_gbq(dat,
                          destination_table=destination_table,
                          project_id=self.project_id,
                          credentials=self.credentials,
                          if_exists=if_exists)
        return True

    def get_df_from_query(self, sql):
        df = pandas_gbq.read_gbq(sql,
                                 project_id=self.project_id,
                                 credentials=self.credentials,
                                 use_bqstorage_api=True)

        return df

    def get_df_from_table_name(self, table_name):
        sql = f'SELECT * FROM {table_name}'
        df = self.get_df_from_query(sql)
        return df
