import scipy.stats as stats
import math
import pandas as pd
import numpy as np

# Parameters
# alpha = 0.05               # Significance level
# power = 0.80               # Desired power
# baseline_revenue = 100     # Average revenue
# std_dev = 15               # Standard deviation
# MDE_percentage = 0.10      # MDE as a percentage (e.g., 10%)
# control_proportion = 0.7   # Proportion of households in control group
# treatment_proportion = 0.3 # Proportion of households in treatment group

# Calculate critical values for Z-scores


def run_power_cal(df, measure_column, target_group_column, MDE,
               control_value='control',test_value='test',
               alpha=0.05, power=0.8):
    try:
        control = df[df[target_group_column] == control_value][measure_column].astype('float64')
        test = df[df[target_group_column] == test_value][measure_column].astype('float64')
        df_test = pd.concat([control, test])
        std_dev = df_test.std()
        baseline = df_test.mean()
        control_prop = control.shape[0]/df_test.shape[0]
        treatment_prop = test.shape[0] / df_test.shape[0]

        if MDE is None:
            MDE = (test.mean() - control.mean())/control.mean()
        else:
            pass


        required_sample_size, control_group_size, treatment_group_size = \
            calculate_sample_size(alpha=alpha, power=power, std_dev=std_dev, baseline=baseline,
                                  control_prop=control_prop,
                                  treatment_prop=treatment_prop,
                                  MDE=MDE)

        return pd.Series({'required_sample': required_sample_size,
                          'test_powered':required_sample_size<=df_test.shape[0]})
    except:
        return pd.Series({'required_sample': np.nan,
                          'test_powered': np.nan})


# Calculate sample size
def calculate_sample_size(alpha, power, std_dev, baseline, MDE, control_prop, treatment_prop):
    z_alpha = stats.norm.ppf(1 - alpha / 2)  # Two-tailed test
    z_beta = stats.norm.ppf(power)  # Power threshold

    absolute_mde = baseline * MDE  # Convert MDE percentage to absolute value
    numerator = (z_alpha + z_beta) ** 2 * (std_dev**2 / control_prop + std_dev**2 / treatment_prop)
    denominator = absolute_mde**2
    required_sample_size = math.ceil(numerator / denominator)
    control_group_size = math.ceil(required_sample_size * control_prop)
    treatment_group_size = math.ceil(required_sample_size * treatment_prop)

    return required_sample_size, control_group_size, treatment_group_size


