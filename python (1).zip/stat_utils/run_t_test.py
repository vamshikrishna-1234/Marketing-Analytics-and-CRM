from statsmodels.stats.weightstats import ttest_ind

def run_t_test(df, measure_column, target_group_column,
               control_value='control',test_value='test'):
    control = df[df[target_group_column] == control_value][measure_column].astype('float64')
    test = df[df[target_group_column] == test_value][measure_column].astype('float64')
    p_value = ttest_ind(control,test, usevar='unequal')[1]
    return p_value