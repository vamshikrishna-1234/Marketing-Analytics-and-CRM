import pandas as pd
from stat_utils.run_t_test import run_t_test
from stat_utils.run_power_cal import run_power_cal

def get_stats(df_split, dimension_variables, test_values,
              measure_variable, MDE,
              target_group_column_name='target_group',
              control_value='control'):

    output_dict = {}

    for var in dimension_variables:
        tmp_list = []
        print(var)
        #output_dict[var] = {}
        for test_value in test_values:
            print(test_value)
            # tmp_dict[test_value] = {}
            df_split_tmp = df_split[df_split[target_group_column_name].isin([test_value,control_value])]
            # if var=='all':
            #     df_g = df_split_tmp.groupby(['constant','target_group'])
            # else:
            df_g = df_split_tmp.groupby([var,target_group_column_name],dropna=False)
            df_g2 = df_split_tmp.groupby([var], dropna=False)

            #start computing
            stats = df_g.aggregate({measure_variable:['count','mean','std']})
            stats.columns = stats.columns.map('_'.join)
            stats = stats.reset_index()
            #stats = stats[stats[measure_variable+'_mean'] != 0]

            # get p value
            t_test = df_g2.apply(lambda x: run_t_test(x, measure_variable,
                                                      test_value=test_value,
                                                      target_group_column=target_group_column_name,
                                                      control_value=control_value))
            t_test.name = 'p_value'
            t_test = t_test.reset_index()
            t_test[target_group_column_name] = test_value


            #run power calculation
            power = df_g2.apply(lambda x: run_power_cal(x, measure_variable,
                                                        MDE=MDE,
                                                        test_value=test_value,
                                                        target_group_column=target_group_column_name,
                                                        control_value=control_value))
            power = power.reset_index()
            power[target_group_column_name] = test_value

            stats = stats.merge(t_test, on=[target_group_column_name, var], how='left')
            stats = stats.merge(power, on=[target_group_column_name, var], how='left')

            #ensure that control comes before test

            customer_order = {control_value:0, test_value:1}
            stats = stats.sort_values(by=[target_group_column_name],
                                      key=lambda x: x.map(customer_order))
            stats = stats.sort_values(by=var, kind='stable')

            #calculate % diff
            stats['diff_perc'] = stats[measure_variable+'_mean'].astype('float').pct_change().\
                where(stats[target_group_column_name] != control_value)

            tmp_list.append(stats)
            print(stats)
        tmp_df = pd.concat(tmp_list)
        tmp_df = tmp_df.drop_duplicates(subset=[target_group_column_name, var], keep='first')

        group_counts = tmp_df.groupby([var, target_group_column_name])[[measure_variable + '_count']].\
            sum().astype('float64')
        overall_counts = tmp_df.groupby([var])[[measure_variable + '_count']].sum().astype('float64')
        perc_counts = group_counts / overall_counts
        perc_counts.columns = ['perc_count']
        perc_counts = perc_counts.reset_index()
        perc_counts['perc_count'] = perc_counts['perc_count'].astype('float')

        tmp_df = tmp_df.merge(perc_counts, on=[target_group_column_name, var],
                              how='left')
        tmp_df = tmp_df.sort_values(by=var, kind='stable')
        #print(tmp_df)
        output_dict[var] = tmp_df

    return output_dict